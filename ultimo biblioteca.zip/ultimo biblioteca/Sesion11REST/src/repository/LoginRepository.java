package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import edu.cibertec.util.MySQLConexion;

public class LoginRepository {
	
	 public boolean ingreso(String usuario, String password){
	        boolean result = false;
	        Connection cn = null;
	        PreparedStatement pstm = null;
	        try {
	            cn = MySQLConexion.getConexion();
	            String sql = "select * from tb_login where usuario = ? and password = ?";
	            pstm = cn.prepareStatement(sql);
	            pstm.setString(1, usuario);
	            pstm.setString(2, password);
	            ResultSet rs = pstm.executeQuery();
	            if( rs.next()){
	                return true;
	           } else {
	               return false;
	           }
	            
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }finally {
	            MySQLConexion.closeStatement(pstm);
	            MySQLConexion.closeConexion(cn);
	        }
	        return result;
	        
	        
	            /*    String username = "myusername";
	                String password = "mypassword";
	                String databaseName = "albums";
	                Connection connect = null;
	                Statement statement = null;
	                try {
	                    Class.forName("com.mysql.jdbc.Driver");
	                    connect = DriverManager.getConnection("jdbc:mysql://localhost/"
	                            + databaseName + "?"
	                            + "user=" + username
	                            + "&password=" + password);
	                    statement = connect.createStatement();
	                    String query = "SELECT * FROM the_classics ORDER BY year";
	                    ResultSet resultSet = statement.executeQuery(query);
	                    while (resultSet.next()) {
	                        System.out.println("Printing result...");
	                        String albumName = resultSet.getString("name");
	                        String artist = resultSet.getString("artist");
	                        int year = resultSet.getInt("year");
	                    }
	                } catch (ClassNotFoundException e) {
	                    e.printStackTrace();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                } finally {
	                    try {
	                        statement.close();
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                    try {
	                        connect.close();
	                    } catch (SQLException e) {
	                        e.printStackTrace();
	                    }
	                }
	            }*/

	    }
	 public int create(String usuario, String password){
		 int result = 0;
	        Connection cn = null;
	        PreparedStatement pstm = null;
	        try {
	            cn = MySQLConexion.getConexion();
	            String sql = "insert into tb_login values(null,?,?,now())";
	            pstm = cn.prepareStatement(sql);
	            pstm.setString(1, usuario);
	            pstm.setString(2, password);
	            result = pstm.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }finally {
	            MySQLConexion.closeStatement(pstm);
	            MySQLConexion.closeConexion(cn);
	        }
	        return result;
	 }
}
