package repository;

import edu.cibertec.util.MySQLConexion;
//import Repository;

import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import beans.AutorResponse;
import beans.LibroResponse;

//@Repository
public class AutorRepository {
    //Metodos
    public int ingreso(String nombre, String apellido, String paisOrigen, String idioma){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "insert into tb_autor values(null,?,?,?,?,now())";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, nombre);
            pstm.setString(2, apellido);
            pstm.setString(3, paisOrigen);
            pstm.setString(4, idioma);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
    public int delete(Integer idAutor){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "delete from tb_autor where idAutor = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, idAutor);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
    public int update(Integer idAutor,String nombre, String apellido, String paisOrigen, String idioma){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "update tb_autor set nombre = ? ,apellido = ?,paisOrigen=?,idioma=? where idAutor = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, nombre);
            pstm.setString(2, apellido);
            pstm.setString(3, paisOrigen);
            pstm.setString(4, idioma);
            pstm.setInt(5, idAutor);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
    public ArrayList<AutorResponse> list(Integer id){
    	ArrayList<AutorResponse>  response = new ArrayList<>();
       // int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        String sql;
        try {
            cn = MySQLConexion.getConexion();
            if(id != null){
            	 sql = "select * from tb_autor where idAutor = ?";
            	 pstm = cn.prepareStatement(sql);
                 pstm.setInt(1, id);  
            }else{
            	 sql = "select * from tb_autor";
            	 pstm = cn.prepareStatement(sql);
            }
            ResultSet resultSet = pstm.executeQuery();
            while (resultSet.next()) {
                String nombre = resultSet.getString("nombre");
                String apellido = resultSet.getString("apellido");
                String paisOrigen = resultSet.getString("paisOrigen");
                String idioma = resultSet.getString("idioma");
                Date fechaRegistro = resultSet.getDate("fechaRegistro");
                response.add(new AutorResponse(nombre,apellido,paisOrigen,idioma,fechaRegistro ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return response;
    }
}
