package repository;

import edu.cibertec.util.MySQLConexion;
//import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import beans.LibroResponse;

//@Repository
public class LibroRepository {
    public int ingreso(Integer idAutor, String nombre, String editorial, String idioma,boolean estado){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "insert into tb_libro values(null,?,?,?,?,?,now())";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, idAutor);
            pstm.setString(2, nombre);
            pstm.setString(3, editorial);
            pstm.setString(4, idioma);
            pstm.setBoolean(5, estado);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
    public int delete(Integer id){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "delete from tb_libro where idLibro = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
    public LibroResponse buscarPorId(Integer id){
    	LibroResponse response = new LibroResponse();
       // int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "select * from tb_libro where idLibro = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            //result = pstm.executeUpdate();
            
            ResultSet resultSet = pstm.executeQuery();
            //result = pstm.executeUpdate();
            while (resultSet.next()) {
                System.out.println("Printing result...");
                String nombre = resultSet.getString("nombre");
                String editorial = resultSet.getString("editorial");
                String idioma = resultSet.getString("idioma");
                boolean estado = resultSet.getBoolean("estado");
                Date fecha = resultSet.getDate("fechaRegistro");
                response.setNombre(nombre);
                response.setEditorial(editorial);
                response.setIdioma(idioma);
                response.setEstado(estado);
                response.setFechaRegistro(fecha);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return response;
    }
    public int update(Integer idLibro,Integer idAutor, String nombre,String editorial,String idioma, boolean estado){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "update tb_libro set idAutor = ?, nombre = ?, editorial = ?, idioma=?, estado=? where idLibro = ? ";
                       
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, idAutor);
            pstm.setString(2, nombre);
            pstm.setString(3, editorial);
            pstm.setString(4, idioma);
            pstm.setBoolean(5, estado);
            pstm.setInt(6, idLibro);

            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
}
