package repository;

import edu.cibertec.util.MySQLConexion;
//import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import beans.BibliotecaResponse;
import beans.PrestamoResponse;

//@Repository
public class PrestamoRepository {
    public int ingreso(Integer idLibro, Integer idBiblioteca, String nombreUsuario,Integer dniUsuario,Boolean estado){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "insert into tb_prestamo values(null,?,?,?,?,?,now())";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, idLibro);
            pstm.setInt(2, idBiblioteca);
            pstm.setString(3, nombreUsuario);
            pstm.setInt(4, dniUsuario);
            pstm.setBoolean(5, estado);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
    
    public int delete(Integer id){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "delete from tb_prestamo where idPrestamo = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
    
	public int update(Integer idPrestamo,Integer idBiblioteca, String nombreUsuario, Integer dniUsuario,Boolean estado){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "update tb_prestamo set idBiblioteca = ? ,nombreUsuario = ?,dniUsuario=?,estado=?  where idPrestamo = ?";
            pstm =  cn.prepareStatement(sql);
            pstm.setInt(1, idBiblioteca);
            pstm.setString(2, nombreUsuario);
            pstm.setInt(3, dniUsuario);
            pstm.setBoolean(4, estado);
            pstm.setInt(5, idPrestamo);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
	public ArrayList<PrestamoResponse> list(Integer id){
    	ArrayList<PrestamoResponse>  response = new ArrayList<>();
       // int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        PreparedStatement pstml = null;
        PreparedStatement pstmb = null;
        String sql;
        ResultSet resultSet;
        ResultSet resultSetLibro;
        ResultSet resultSetBiblioteca;
        try {
            cn = MySQLConexion.getConexion();
            if(id != null){
            	 sql = "select * from tb_prestamo where idPrestamo = ?";
            	 pstm = cn.prepareStatement(sql);
                 pstm.setInt(1, id);  
            }else{
            	 sql = "select * from tb_prestamo";
            	 pstm = cn.prepareStatement(sql);
            }
            resultSet = pstm.executeQuery();
            while (resultSet.next()) {
                String nombreUsuario = resultSet.getString("nombreUsuario");
                Integer dniUsuario = resultSet.getInt("dniUsuario");
                Boolean estado = resultSet.getBoolean("estado");
                Date fechaRegistro = resultSet.getDate("fechaRegistro");
                Integer idLibro = resultSet.getInt("idLibro");
                Integer idBiblioteca = resultSet.getInt("idBiblioteca");
                String nombreLibro = "";
                String nombreBiblioteca = "";
                if(idLibro!=null && idBiblioteca != null){
                	sql = "select * from tb_libro where idLibro = ?";
                	pstml = cn.prepareStatement(sql);
                	pstml.setInt(1, idLibro); 
                    resultSetLibro = pstml.executeQuery();
                    while (resultSetLibro.next()) {
                        nombreLibro = resultSet.getString("nombre");
                        //response.setNombre(nombre);
                    }
                    sql = "select * from tb_biblioteca where idBiblioteca = ?";
                    pstmb = cn.prepareStatement(sql);
                    pstmb.setInt(1, idBiblioteca); 
                    resultSetBiblioteca = pstmb.executeQuery();
                    while (resultSetBiblioteca.next()) {
                        nombreBiblioteca = resultSet.getString("nombre");
                        //response.setNombre(nombre);
                    }
                }
                
               // String nombreLibro = resultSet.getString("nombreLibro");
               // String nombreBiblioteca = resultSet.getString("nombreBiblioteca");
                response.add(new PrestamoResponse(nombreUsuario,dniUsuario,estado,fechaRegistro,nombreLibro,nombreBiblioteca ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return response;
    }
}
