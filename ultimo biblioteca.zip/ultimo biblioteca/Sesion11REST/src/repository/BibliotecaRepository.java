package repository;

import edu.cibertec.util.MySQLConexion;
//import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import beans.AutorResponse;
import beans.BibliotecaResponse;

//@Repository
public class BibliotecaRepository {
    public int ingreso(String nombre, String direccion, String referenciaDireccion){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "insert into tb_biblioteca values(null,?,?,?,now())";
            pstm = cn.prepareStatement(sql);
            pstm.setString(1, nombre);
            pstm.setString(2, direccion);
            pstm.setString(3, referenciaDireccion);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }

    public int delete(Integer id){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "delete from tb_biblioteca where idBiblioteca = ?";
            pstm = cn.prepareStatement(sql);
            pstm.setInt(1, id);
            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
	public int update(Integer idBiblioteca,String nombre, String direccion, String referenciaDireccion){
        int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        try {
            cn = MySQLConexion.getConexion();
            String sql = "update tb_biblioteca set nombre = ? ,direccion = ?,referenciaDireccion=?  where idBiblioteca = ?";
            pstm =  cn.prepareStatement(sql);
            pstm.setString(1, nombre);
            pstm.setString(2, direccion);
            pstm.setString(3, referenciaDireccion);
            pstm.setInt(4, idBiblioteca);

            result = pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return result;
    }
	
	public ArrayList<BibliotecaResponse> list(Integer id){
    	ArrayList<BibliotecaResponse>  response = new ArrayList<>();
       // int result = 0;
        Connection cn = null;
        PreparedStatement pstm = null;
        String sql;
        try {
            cn = MySQLConexion.getConexion();
            if(id != null){
            	 sql = "select * from tb_biblioteca where idBiblioteca = ?";
            	 pstm = cn.prepareStatement(sql);
                 pstm.setInt(1, id);  
            }else{
            	 sql = "select * from tb_biblioteca";
            	 pstm = cn.prepareStatement(sql);
            }
            ResultSet resultSet = pstm.executeQuery();
            while (resultSet.next()) {
                String nombre = resultSet.getString("nombre");
                String direccion = resultSet.getString("direccion");
                String referenciaDireccion = resultSet.getString("referenciaDireccion");
                Date fechaRegistro = resultSet.getDate("fechaRegistro");
                response.add(new BibliotecaResponse(nombre,direccion,referenciaDireccion,fechaRegistro ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MySQLConexion.closeStatement(pstm);
            MySQLConexion.closeConexion(cn);
        }
        return response;
    }
}
