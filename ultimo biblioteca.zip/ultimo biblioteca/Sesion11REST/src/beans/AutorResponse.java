package beans;

import java.util.Date;

public class AutorResponse {
	private String nombre;
	private String apellido;
	private String paisOrigen;
	private String idioma;
	private Date fechaRegistro;
	
	
	
	public AutorResponse() {
		super();
	}
	public AutorResponse(String nombre, String apellido, String paisOrigen, String idioma, Date fechaRegistro) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.paisOrigen = paisOrigen;
		this.idioma = idioma;
		this.fechaRegistro = fechaRegistro;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getPaisOrigen() {
		return paisOrigen;
	}
	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}
	public String getIdioma() {
		return idioma;
	}
	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	@Override
	public String toString() {
		return "AutorResponse [nombre=" + nombre + ", apellido=" + apellido + ", paisOrigen=" + paisOrigen + ", idioma="
				+ idioma + ", fechaRegistro=" + fechaRegistro + "]";
	}
	
	
}
