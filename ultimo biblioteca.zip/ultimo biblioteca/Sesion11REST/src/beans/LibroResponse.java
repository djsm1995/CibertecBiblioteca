package beans;

import java.util.Date;

//@JsonInclude(JsonInclude.Include.)
public class LibroResponse {
	private String nombre;
	private String editorial;
	private String idioma;
	private boolean estado;
	private Date fechaRegistro;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEditorial() {
		return editorial;
	}
	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}
	public String getIdioma() {
		return idioma;
	}
	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}
	public boolean isEstado() {
		return estado;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	
	@Override
	public String toString() {
		return "LibroResponse [nombre=" + nombre + ", editorial=" + editorial + ", idioma=" + idioma + ", estado="
				+ estado + ", fechaRegistro=" + fechaRegistro + "]";
	}
	
	
	
	

}
