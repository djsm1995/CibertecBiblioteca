package beans;

import java.util.Date;

public class PrestamoResponse {
	  private Integer idLibro ;
	  private Integer idBiblioteca; 
	  private String nombreUsuario;
	  private Integer dniUsuario;
	  private Boolean estado;
	  private Date fechaRegistro;
	  
	  private String nombreLibro;
	  private String nombreBiblioteca;
	  
	public PrestamoResponse() {
		super();
	}
	
	public PrestamoResponse(String nombreUsuario, Integer dniUsuario, Boolean estado, Date fechaRegistro,
			String nombreLibro, String nombreBiblioteca) {
		super();
		this.nombreUsuario = nombreUsuario;
		this.dniUsuario = dniUsuario;
		this.estado = estado;
		this.fechaRegistro = fechaRegistro;
		this.nombreLibro = nombreLibro;
		this.nombreBiblioteca = nombreBiblioteca;
	}



	public Integer getIdLibro() {
		return idLibro;
	}
	public void setIdLibro(Integer idLibro) {
		this.idLibro = idLibro;
	}
	public Integer getIdBiblioteca() {
		return idBiblioteca;
	}
	public void setIdBiblioteca(Integer idBiblioteca) {
		this.idBiblioteca = idBiblioteca;
	}
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
	public Integer getDniUsuario() {
		return dniUsuario;
	}
	public void setDniUsuario(Integer dniUsuario) {
		this.dniUsuario = dniUsuario;
	}
	public Boolean getEstado() {
		return estado;
	}
	public void setEstado(Boolean estado) {
		this.estado = estado;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getNombreLibro() {
		return nombreLibro;
	}
	public void setNombreLibro(String nombreLibro) {
		this.nombreLibro = nombreLibro;
	}
	public String getNombreBiblioteca() {
		return nombreBiblioteca;
	}
	public void setNombreBiblioteca(String nombreBiblioteca) {
		this.nombreBiblioteca = nombreBiblioteca;
	}
	@Override
	public String toString() {
		return "PrestamoResponse [nombreUsuario=" + nombreUsuario + ", dniUsuario=" + dniUsuario + ", estado=" + estado
				+ ", fechaRegistro=" + fechaRegistro + ", nombreLibro=" + nombreLibro + ", nombreBiblioteca="
				+ nombreBiblioteca + "]";
	}
}
