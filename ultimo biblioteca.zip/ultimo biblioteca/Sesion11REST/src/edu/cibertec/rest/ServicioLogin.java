package edu.cibertec.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


import repository.LoginRepository;

@Path("login")
public class ServicioLogin {
	LoginRepository loginRepository = new LoginRepository();
	
	@GET
	@Path("ingreso")
	@Produces(MediaType.TEXT_PLAIN)
	public String ingresoSistema(
			@QueryParam("usuario") String usuario,
			@QueryParam("password") String password
			){
		
		boolean resultado = loginRepository.ingreso(usuario , password);
		if(!resultado){
			return "Credenciales Incorrectas";
		}else{
			return "Ingreso Exitoso: "+usuario;
		}
	}
	@GET
	@Path("create")
	@Produces(MediaType.TEXT_PLAIN)
	public String crearUsuario(
			@QueryParam("usuario") String usuario,
			@QueryParam("password") String password
			){
		
		int resultado = loginRepository.create(usuario , password);
		if(resultado == 0){
			return "No se puedo crear el usuario";
		}else{
			return "Usuario creado: "+usuario;
		}
	}

}
