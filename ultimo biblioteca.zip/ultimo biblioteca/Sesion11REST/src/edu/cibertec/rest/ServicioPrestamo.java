package edu.cibertec.rest;

import repository.PrestamoRepository;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import beans.BibliotecaResponse;
import beans.PrestamoResponse;


@Path("prestamo")
public class ServicioPrestamo {
	PrestamoRepository prestamoRepository = new PrestamoRepository();
	@GET
	@Path("ingreso")
	@Produces(MediaType.TEXT_PLAIN)
	public String ingresarPrestamo(
			@QueryParam("idLibro") Integer idLibro,
			@QueryParam("idBiblioteca") Integer idBiblioteca,
			@QueryParam("nombreUsuario") String nombreUsuario,
			//@PathVariable("estado") Boolean estado,
			@QueryParam("dniUsuario") Integer dniUsuario
			){
		boolean estado = true;
		int resultado = prestamoRepository.ingreso(idLibro, idBiblioteca,nombreUsuario,dniUsuario,estado);
		if(resultado == 0){
			return "No se pudo registrar el prestamo";
		}else{
			return "Prestamo Registrado: "+nombreUsuario;
		}
	}
	@GET
	@Path("update")
	@Produces(MediaType.TEXT_PLAIN)
	public String actualizarPrestamo(
			@QueryParam("idPrestamo") Integer idPrestamo,
			@QueryParam("idBiblioteca") Integer idBiblioteca,
			@QueryParam("nombreUsuario") String nombreUsuario,
			@QueryParam("dniUsuario") Integer dniUsuario,
			@QueryParam("estado") Boolean estado
	) {

		int resultado = prestamoRepository.update(idPrestamo, idBiblioteca, nombreUsuario, dniUsuario,estado);
		if (resultado == 0) {
			return "No se pudo actualizar el prestamo";
		} else {
			return "Prestamo actualizado: " + nombreUsuario;
		}
	}

	@GET
	@Path("delete")
	@Produces(MediaType.TEXT_PLAIN)
	public String eliminarPrestamo(
			@QueryParam("idPrestamo") Integer id
	) {

		int resultado = prestamoRepository.delete(id);
		if (resultado == 0) {
			return "No se pudo eliminar el prestamo";
		} else {
			return "Prestamo Eliminado: " + id;
		}
	}
	
	@GET
    @Path("list")
    @Produces(MediaType.TEXT_PLAIN)
    //@GetMapping(value = "delete", produces = {MediaType.APPLICATION_JSON_VALUE})
    public String listarPrestamo(
    		@QueryParam("idPrestamo") Integer idPrestamo
    ) {
    	ArrayList<PrestamoResponse> resultado = prestamoRepository.list(idPrestamo);
        if (resultado.equals("")) {
            return "No se pudo encontrar el dato solicitado";
        } else {
            return "listado: " + resultado.toString();
        }
    }

}
