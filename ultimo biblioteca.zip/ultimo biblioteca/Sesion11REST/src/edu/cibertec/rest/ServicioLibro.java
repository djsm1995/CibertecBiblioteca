package edu.cibertec.rest;

import repository.LibroRepository;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import beans.LibroResponse;

///@RestController
///@RequestMapping("libro")
@Path("libro")
public class ServicioLibro {
	LibroRepository libroRepository = new LibroRepository();
	
	@GET
	@Path("ingreso")
	@Produces(MediaType.TEXT_PLAIN)
	public String ingresarLibro(
			@QueryParam("idAutor") Integer idAutor,
			@QueryParam("nombre") String nombre,
			@QueryParam("editorial") String editorial,
			@QueryParam("idioma") String idioma,
			@QueryParam("estado") boolean estado
			){
		
		int resultado = libroRepository.ingreso(idAutor, nombre, editorial,idioma,estado);
		if(resultado == 0){
			return "No se pudo registrar libro";
		}else{
			return "Libro Registrado: "+nombre;
		}
	}
	@GET
	@Path("update")
	@Produces(MediaType.TEXT_PLAIN)
	public String actualizarLibro(
			@QueryParam("idLibro") Integer idLibro,
			@QueryParam("idAutor") Integer idAutor,
			@QueryParam("nombre") String nombre,
			@QueryParam("editorial") String editorial,
			@QueryParam("idioma") String idioma,
			@QueryParam("estado") Boolean estado
	) {

		int resultado = libroRepository.update(idLibro,idAutor, nombre, editorial,idioma,estado);
		if (resultado == 0) {
			return "No se pudo actualizar el libro";
		} else {
			return "Libro actualizado: " + nombre;
		}
	}

	@GET
	@Path("delete")
	@Produces(MediaType.TEXT_PLAIN)
	public String eliminarLibro(
			@QueryParam("idLibro") Integer id
	) {
		int resultado = libroRepository.delete(id);
		if (resultado == 0) {
			return "No se pudo eliminar libro";
		} else {
			return "Libro eliminado: " + id;
		}
	}
	@GET
	@Path("buscarLibro")
	@Produces(MediaType.TEXT_PLAIN)
	public String BuscarLibro(
			@QueryParam("idLibro") Integer id
	) {
		
		LibroResponse resultado = libroRepository.buscarPorId(id);
		if (resultado == null) {
			return "No se puedo encontrar el dato solicitado";
		} else {
			return "Libro: " + resultado.toString();
		}
	}

}
