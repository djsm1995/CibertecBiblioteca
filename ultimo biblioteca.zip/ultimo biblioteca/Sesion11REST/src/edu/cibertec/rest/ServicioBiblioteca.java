package edu.cibertec.rest;

import repository.BibliotecaRepository;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import beans.AutorResponse;
import beans.BibliotecaResponse;

//@RestController
//@RequestMapping("biblioteca")
@Path("biblioteca")
public class ServicioBiblioteca {
	BibliotecaRepository bibliotecaRepository = new BibliotecaRepository();
	
	@GET
	@Path("ingreso")
	@Produces(MediaType.TEXT_PLAIN)
	public String ingresarBiblioteca(
			@QueryParam("nombre") String nombre,
			@QueryParam("direccion") String direccion,
			@QueryParam("referenciaDireccion") String referenciaDireccion
			){
		
		int resultado = bibliotecaRepository.ingreso(nombre, direccion, referenciaDireccion);
		if(resultado == 0){
			return "No se pudo registrar la biblioteca";
		}else{
			return "Biblioteca Registrada: "+nombre;
		}
	}

	@GET
	@Path("update")
	@Produces(MediaType.TEXT_PLAIN)
	public String actualizarBiblioteca(
			@QueryParam("idBiblioteca") Integer idBiblioteca,
			@QueryParam("nombre") String nombre,
			@QueryParam("direccion") String direccion,
			@QueryParam("referenciaDireccion") String referenciaDireccion
	) {

		int resultado = bibliotecaRepository.update(idBiblioteca, nombre, direccion, referenciaDireccion);
		if (resultado == 0) {
			return "No se pudo actualizar la Biblioteca";
		} else {
			return "Biblioteca actualizado: " + nombre;
		}
	}

	@GET
	@Path("delete")
	@Produces(MediaType.TEXT_PLAIN)
	public String eliminarBiblioteca(
			@QueryParam("idBiblioteca") Integer id
	) {

		int resultado = bibliotecaRepository.delete(id);
		if (resultado == 0) {
			return "No se pudo eliminar la biblioteca";
		} else {
			return "Biblioteca actualizado: " + id;
		}
	}
	@GET
    @Path("list")
    @Produces(MediaType.TEXT_PLAIN)
    //@GetMapping(value = "delete", produces = {MediaType.APPLICATION_JSON_VALUE})
    public String listarBiblioteca(
    		@QueryParam("idBiblioteca") Integer idBiblioteca
    ) {
    	ArrayList<BibliotecaResponse> resultado = bibliotecaRepository.list(idBiblioteca);
        if (resultado.equals("")) {
            return "No se pudo encontrar el dato solicitado";
        } else {
            return "listado: " + resultado.toString();
        }
    }
}
