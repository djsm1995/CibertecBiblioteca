package edu.cibertec.rest;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

//import repository.AutorRepository;
import javax.ws.rs.core.MediaType;

import beans.AutorResponse;
import repository.AutorRepository;


@Path("autor")
public class ServicioAutor {
    //@Autowired
    //AutorRepository autorRepository;
 AutorRepository autor = new AutorRepository();   
    @GET
	@Path("ingreso")
	@Produces(MediaType.TEXT_PLAIN)
    public String ingresarAutor(
    		@QueryParam("nombre") String nombre,
    		@QueryParam("apellido") String apellido,
    		@QueryParam("paisOrigen") String paisOrigen,
    		@QueryParam("idioma") String idioma) {

        int resultado = autor.ingreso(nombre, apellido, paisOrigen, idioma);
        
        if (resultado == 0) {
            return "No se pudo registrar al Autor";
        } else {
            return "Autor Registrado: " + nombre;
        }
    }

    @GET
    @Path("update")
    @Produces(MediaType.TEXT_PLAIN)
    public String actualizarAutor(
    		@QueryParam("idAutor") Integer idAutor,
    		@QueryParam("nombre") String nombre,
    		@QueryParam("apellido") String apellido,
    		@QueryParam("paisOrigen") String paisOrigen,
            @QueryParam("idioma") String idioma
    ) {

        int resultado = autor.update(idAutor, nombre, apellido, paisOrigen, idioma);
        if (resultado == 0) {
            return "No se pudo actualizar al Autor";
        } else {
            return "Autor actualizado: " + nombre;
        }
    }

    @GET
    @Path("delete")
    @Produces(MediaType.TEXT_PLAIN)
    //@GetMapping(value = "delete", produces = {MediaType.APPLICATION_JSON_VALUE})
    public String eliminarAutor(
    		@QueryParam("idAutor") Integer idAutor
    ) {

        int resultado = autor.delete(idAutor);
        if (resultado == 0) {
            return "No se pudo actualizar al Autor";
        } else {
            return "Autor actualizado: " + idAutor;
        }
    }
    @GET
    @Path("list")
    @Produces(MediaType.TEXT_PLAIN)
    //@GetMapping(value = "delete", produces = {MediaType.APPLICATION_JSON_VALUE})
    public String listarAutor(
    		@QueryParam("idAutor") Integer idAutor
    ) {
    	ArrayList<AutorResponse> resultado = autor.list(idAutor);
        if (resultado.equals("")) {
            return "No se pudo encontrar el dato solicitado";
        } else {
            return "listado: " + resultado.toString();
        }
    }
}
