drop database biblioteca;
create database biblioteca;
use biblioteca;
create table tb_autor
(
  idAutor int primary key auto_increment,
  nombre varchar(50),
  apellido varchar(50),
  paisOrigen varchar(50),
  idioma varchar(50),
  fechaRegistro date
);
select * from tb_autor;
create table tb_biblioteca
(
 idBiblioteca int primary key auto_increment,
 nombre varchar(50),
 direccion varchar(50),
 referenciaDireccion varchar(50),  
 fechaRegistro date	
);
create table tb_libro
(
 idLibro int primary key auto_increment,
 idAutor int,
 nombre varchar(50),
 editorial varchar(50),
 idioma varchar(50),
 estado boolean,
 fechaRegistro date
);
create table tb_prestamo
(
  idPrestamo int primary key auto_increment, 
  idLibro int,
  idBiblioteca int, 
  nombreUsuario varchar(50),
  dniUsuario int,
  estado boolean,
  fechaRegistro date
);
select * from tb_prestamo;
create table tb_login
(
 idUsuario int primary key auto_increment,
 usuario varchar(50),
 password varchar(50),
 fechaRegistro date
);
select * from tb_login;

--http://localhost:8080/Sesion11REST/rest/venta/ingreso?codProd=002&cantidad=10&precio=10&categoria=1&oferta=0
--servicios Autor--
--http://localhost:8080/Sesion11REST/rest/autor/delete?idAutor=1
--http://localhost:8080/Sesion11REST/rest/autor/ingreso?nombre=diego2&apellido=santos&paisOrigen=peru&idioma=espa
--http://localhost:8080/Sesion11REST/rest/autor/update?idAutor=2&nombre=diego3&apellido=santos&paisOrigen=peru&idioma=espa
--http://localhost:8080/Sesion11REST/rest/autor/list?idAutor=1
--servicios Biblioteca
--http://localhost:8080/Sesion11REST/rest/biblioteca/ingreso?nombre=biblioteca1&direccion=miraflores&referenciaDireccion=ovalo
--http://localhost:8080/Sesion11REST/rest/biblioteca/delete?idBiblioteca=1
--http://localhost:8080/Sesion11REST/rest/biblioteca/update?idBiblioteca=2&nombre=biblioteca4&direccion=miraflores&referenciaDireccion=ovalo
--Servicio Libro--
--http://localhost:8080/Sesion11REST/rest/libro/ingreso?idAutor=1&nombre=libro1&editorial=SanFrancisco&idioma=ingles&estado=true
--http://localhost:8080/Sesion11REST/rest/libro/update?idLibro=2&idAutor=1&nombre=libro1&editorial=San%20Francisco&idioma=ingles&estado=false
--http://localhost:8080/Sesion11REST/rest/libro/delete?idLibro=2
--http://localhost:8080/Sesion11REST/rest/libro/buscarLibro?idLibro=3--
--servicio LOGIN
--http://localhost:8080/Sesion11REST/rest/login/create?usuario=diego&password=123456
---http://localhost:8080/Sesion11REST/rest/login/ingreso?usuario=diego&password=123456 --Modificar la query

---todo solo hasta el 4.3 (Tabla de Contenidos)

---Servicio PRESTAMO .
--http://localhost:8080/Sesion11REST/rest/prestamo/ingreso?idLibro=1&idBiblioteca=1&nombreUsuario=San&dniUsuario=1
--http://localhost:8080/Sesion11REST/rest/prestamo/delete?idPrestamo=1
--http://localhost:8080/Sesion11REST/rest/prestamo/update?idPrestamo=2&idLibro=1&idBiblioteca=1&nombreUsuario=San&dniUsuario=6587454&estado=false
